setwd("/home/cor/ws_scr_nki/screensaver/R/cellHTS2Db/tests")
#source("doRUnit.R")
#debug <- TRUE
##
library(cellHTS2Db)
 library(RUnit)
#
####EDIT the workdirectory so it fits your own situation
#setwd("/home/cor/ws_screensaver/screensaverCollaboration/R/cellHTS2Db")
###
#######	I RUNNING THE TESTSUITE
#testSuite <- defineTestSuite(name="CellHTS2 integration",dirs="tests", testFileRegexp="^runit.+[rR]$",
#		testFuncRegexp="^test.+")
#isValidTestSuite(testSuite)
#testResult <- runTestSuite(testSuite, useOwnErrorHandler=TRUE)
#printTextProtocol(testResult)


###II RUNNING INDIVIDUAL TESTS IN NORMAL MODE
#
#testResult <- runTestFile("../inst/unitTests/runitReadPlateListDb.R")
# testResult <- runTestFile("../inst/unitTests/runitReadPlateListCommon.R")
#testResult <- runTestFile("../inst/unitTests/runitConfigureDb.R")
#testResult <- runTestFile("../inst/unitTests/runitAnnotateDb.R")
#testResult <- runTestFile("../inst/unitTests/runitNormalizePlates.R")
#testResult <- runTestFile("../inst/unitTests/runitScoreReplicates.R")
## source("../inst/unitTests/makeDummies.R")
## testResult <- runTestFile("../inst/unitTests/runitWriteReport.R")

#printTextProtocol(testResult)

##III RUNNING TESTS IN DEBUG MODE

#source("../R/readPlateListDb.R")
#source("../inst/unitTests/runitReadPlateListDb.R")
#debug(testCreateIntensityFile)
#testCreateIntensityFile(T)
#
#source("../inst/unitTests/runitReadPlateListDb.R")
#debug(testCreatePlateListAndIntensityFiles)
#testCreatePlateListAndIntensityFiles()
#
#source("../inst/unitTests/runitReadPlateListDb.R")
#debug(testReadPlateListDb1)
#testReadPlateListDb1()

#source("../inst/unitTests/runitReadPlateListCommon.R")
##debug(testReadPlateListCommon)
#testReadPlateListCommon()

## source("../inst/unitTests/runitConfigureDb.R")
## debug(testConfigureDb1)
## testConfigureDb1(T)

## source("../inst/unitTests/runitAnnotateDb.R")
## testAnnotateDb1()
## #
source("../inst/unitTests/runitNormalizePlates.R")
source("../R/configureDb.R")
debug(testNormalizeNegatives)
testNormalizeNegatives(T)

## #debug(testNormalizeMean)
## #testNormalizeMean()
## debug(testNormalizeMeanWithSlog)
## testNormalizeMeanWithSlog(T)

#source("../inst/unitTests/runitScoreReplicates.R")
#testScoreReplicates1(debug)

#source("../inst/unitTests/runitSummarizeReplicates.R")
#debug(summarizeReplicates)
#testSummarizeReplicates1(debug)

## source("../inst/unitTests/runitWriteReport.R")
## testWriteReport1()

#source("../inst/unitTests/runitIntegrationTest.R")
#testIntegrationTest1()

#source("../inst/unitTests/runitReadPlateListUsingCommon.R")
#debug(testReadPlateListUsingCommon1)
#testReadPlateListUsingCommon1()







