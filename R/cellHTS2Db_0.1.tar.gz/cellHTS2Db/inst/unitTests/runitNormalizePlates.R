testNormalizeMean <- function(debug=FALSE,withSlog=FALSE) {
	source("../inst/unitTests/createRca.R")
	rca <- createRca(withSlog)
	
	if (debug) 
		debug(normalizePlates)
	
	#see if annotation is required for normalizePlates
	rcan <- normalizePlates(rca,method="median");
	
	dataNorm <- Data(rcan)

	dataNormTarget <- makeNormTarget(withSlog)	
	#browser()
	checkEquals(dataNormTarget,dataNorm)
	
}

testNormalizeMeanWithSlog <- function(debug=FALSE) {
	testNormalizeMean(debug,TRUE)
}


#testNormalizeMeanWithoutAnno <- function(debug=FALSE) {
#	prepareInputTestNormalize(FALSE);
#	
#	if (debug) 
#		debug(normalizePlates)
#	
#	rcn <- normalizePlates(rc,method="median");
#	#save(rcan, file="data/rcan.Rda")
#	
#	dataNorm <- Data(rcn)
#	
#	dataNormTarget <- makeNormTarget()	
#	#browser()
#	checkEquals(dataNormTarget,dataNorm)
#	
#}