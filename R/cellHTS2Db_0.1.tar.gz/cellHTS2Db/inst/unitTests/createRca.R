createRca <- function(withSlog =FALSE) {
	## The workdirectory is set by the Makefile to tests/ because there is doRUnit.R
	## Paths are therefore relative to that directory
	source("../inst/unitTests/makeDummies.R")
	testSet <- makeTestSet(withSlog)
	xrawd <- dim(testSet$xraw)
	r <- readPlateListDb(testSet$xraw, testSet$name, testSet$nrRowsPlate, testSet$nrColsPlate)
	
	if (withSlog) {
		rc <- configureDb(r,testSet$conf,testSet$slog)
	}else {
		rc <- configureDb(r,testSet$conf)
	}
		
	rca <- annotateDb(rc,testSet$geneIDs)
	return(rca)
}